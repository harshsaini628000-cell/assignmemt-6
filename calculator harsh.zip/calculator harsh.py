from tkinter import*
window = Tk()
window.geometry('500x500')
e = Entry(window, width=45,borderwidth=5)
e.place(x=0,y=0)
def click (num):
    result = e.get()
    e.delete(0,END)
    e.insert(0,str(result)+str(num))
b = Button(window,text = '1',width = 12,command=lambda:click(1),bg ='violet')
b.place(x=10,y=60)    
b = Button(window,text = '2',width = 12,command=lambda:click(2),bg = 'grey')
b.place(x=80,y=60)
b = Button(window,text = '3',width = 12,command=lambda:click(3),bg = 'maroon')
b.place(x=170,y=60)
b = Button(window,text = '4',width = 12,command=lambda:click(4),bg = 'red')
b.place(x=10,y=120)
b = Button(window,text = '5',width = 12,command=lambda:click(5),bg= 'green')
b.place(x=80,y=120)
b = Button(window,text = '6',width = 12,command=lambda:click(6),bg = 'teal')
b.place(x=170,y=120)
b = Button(window,text = '7',width = 12,command=lambda:click(7),bg = 'tan')
b.place(x=10,y=180)
b = Button(window,text = '8',width = 12,command=lambda:click(8), bg = 'orange')
b.place(x=80,y=180)
b = Button(window,text = '9',width = 12,command=lambda:click(9),bg = 'indigo')
b.place(x=170,y=180)
b = Button(window,text = '0',width = 12,command=lambda:click(0),bg= 'olive')
b.place(x=10,y=240)


def add():
    n1 = e.get()
    global math
    math = "addition"
    global i
    i = int(n1)
    e.delete(0,END)
b = Button(window,text = '+',width = 12,command= add,bg = 'blue')
b.place(x=80,y=240)

def sub():
    n1 = e.get()
    global math
    math = "subtraction"
    global i
    i = int(n1)
    e.delete(0,END)
b = Button(window,text = '-',width = 12,command=sub,bg= 'green')
b.place(x=170,y=240)

def mult():
    n1 = e.get()
    global math
    math = "multiplaction"
    global i
    i = int(n1)
    e.delete(0,END)
b = Button(window,text = '*',width = 12,command=mult,bg= 'yellow')
b.place(x=10,y=300)

def div():  
    n1 = e.get()
    global math
    math = "division"
    global i
    i = int(n1)
    e.delete(0,END)
b = Button(window,text = '/',width = 12,command=div ,bg='red')
b.place(x=80,y=300)

def equal():   
    n2 = e.get()
    e.delete(0,END)
    
    if math == "addition" :
        e.insert(0,i + int(n2))
    
    elif math == "subtraction":
        e.insert(0,i - int(n2))
    
    
    elif math == "multiplaction":
        e.insert(0,i * int(n2))
   
    elif math == "division": 
        e.insert (0, i / int (n2))   
b = Button(window,text = '=',width = 12,command=equal,bg= 'pink')
b.place(x=170,y=300)

def clear():
    e.delete(0,END)
b = Button (window,text = 'clear',width = 12,command= clear,bg ='red')
b.place(x=10,y=350)

mainloop()

